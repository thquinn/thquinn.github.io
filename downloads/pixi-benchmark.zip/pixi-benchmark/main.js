// We have included PixiJs 5 JavaScript library without exports.
// We do not need the following line:
// import * as PIXI from 'pixi.js'
define(["require", "exports", "my-module"], function (require, exports, my_module_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var app;
    var containers = [];
    var sprite;
    var text;
    var avgFPS = 60;
    var texture;
    var multitouch;
    function main() {
        texture = PIXI.Texture.from('assets/gel.png');
        app = new PIXI.Application({ width: 1200, height: 1200, antialias: true, resolution: window.devicePixelRatio, autoDensity: true });
        document.body.style.margin = '0';
        app.renderer.view.style.position = 'absolute';
        app.renderer.view.style.display = 'block';
        let gameCanvasContainer = document.getElementById('gameCanvasContainer');
        window.onresize = resize;
        resize();
        gameCanvasContainer.appendChild(app.view);
        text = new PIXI.Text("", { fill: 0xffffff, align: 'right' });
        app.stage.addChild(text);
        app.stage.interactive = true;
        multitouch = new my_module_1.Multitouch(app);
        text.anchor.set(1, 0);
        app.ticker.add((delta) => update(delta));
    }
    function resize() {
        app.renderer.resize(window.innerWidth, window.innerHeight);
    }
    function update(delta) {
        let fps = app.ticker.FPS;
        avgFPS = avgFPS * .8 + fps * .2;
        if (avgFPS > 59) {
            let container = new PIXI.Container();
            for (let x = -500; x <= 500; x += 200) {
                for (let y = -500; y <= 500; y += 200) {
                    let s = new PIXI.Sprite(texture);
                    s.anchor.set(.5);
                    if (x == 500 && y == 500) {
                        x += 250;
                    }
                    s.x = x;
                    s.y = y;
                    container.addChild(s);
                    sprite = s;
                }
            }
            app.stage.addChild(container);
            containers.push(container);
        }
        for (let i = 0; i < containers.length; i++) {
            let container = containers[i];
            container.x = app.renderer.width / app.renderer.resolution / 2;
            container.y = app.renderer.height / app.renderer.resolution / 2;
            container.scale.set(.8);
            let hash = (((i * .1031) % 1) + 33.33) * i;
            hash = hash * hash + hash;
            hash = hash % 1;
            let rotation = hash * .02 - .01;
            container.rotation += rotation;
        }
        text.x = app.renderer.width / app.renderer.resolution;
        text.y = 0;
        text.text = Math.round(avgFPS).toString() + "\n" + (containers.length * 36).toString() + "\n" + multitouch.touches.size;
    }
    main();
});
//# sourceMappingURL=main.js.map