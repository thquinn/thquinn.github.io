define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Multitouch = void 0;
    class Multitouch {
        constructor(app) {
            this.touches = new Map();
            let interaction = app.renderer.plugins.interaction;
            interaction.on('touchstart', this.touchStart, this);
            interaction.on('touchmove', this.touchMove, this);
            interaction.on('touchend', this.touchEnd, this);
        }
        touchStart(event) {
            this.touches.set(event.data.identifier, [event.data.global.x, event.data.global.y]);
        }
        touchMove(event) {
            this.touches.set(event.data.identifier, [event.data.global.x, event.data.global.y]);
        }
        touchEnd(event) {
            this.touches.delete(event.data.identifier);
        }
    }
    exports.Multitouch = Multitouch;
});
//# sourceMappingURL=my-module.js.map